package br.com.lirasistema.promocao.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class DemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
